#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <syslog.h>

volatile sig_atomic_t flag = 0;

void handle_signal(int sig) {
    if (sig == SIGINT) {
        flag = 1;
    }
}

int main() {
    // Öffne das Systemlog
    openlog("hello", LOG_PID, LOG_USER);

    // Registriere den Signal-Handler für SIGINT (Strg + C)
    signal(SIGINT, handle_signal);

    // Endlosschleife
    while (!flag) {
        // Führe hier deine Aufgaben aus, z.B. Ausgabe von "Hello, world!"
        printf("Hello, world!\n");

        // Protokolliere Statusänderungen im Systemlog
        syslog(LOG_INFO, "Hello, world!");

        // Hier kannst du auch auf Benutzereingaben warten oder andere Ereignisse überprüfen
        // Wenn ein Ereignis eintritt, setze 'flag' auf 1, um die Schleife zu beenden

        // Warte für eine kurze Zeit, bevor du die Schleife wieder durchläufst
        sleep(1);
    }

    // Wenn die Schleife durch SIGINT beendet wird, gib eine Abschlussmeldung aus
    printf("Programm wurde beendet.\n");

    // Schließe das Systemlog
    closelog();

    return 0;
}

